import React from "react";
import "../shared/App.css";

const Header = () => {
  return (
    <div className="footer">
      <p>2021 @TaeBbong, All rights reserved</p>
    </div>
  );
};

export default Header;
