export { default as Main } from "./Main";
export { default as Like } from "./Like";
export { default as My } from "./My";
export { default as Login } from "./Login";
export { default as Register } from "./Register";
export { default as Detail } from "./Detail";
export { default as New } from "./New";
export { default as Profile } from "./Profile";
