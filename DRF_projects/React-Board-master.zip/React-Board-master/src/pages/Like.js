import React, { Component } from "react";
import { Grid } from "../components/index";

class Like extends Component {
  render() {
    return (
      <div className="Like">
        <Grid />
      </div>
    );
  }
}

export default Like;
