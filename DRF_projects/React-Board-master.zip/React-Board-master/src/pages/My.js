import React, { Component } from "react";
import { Grid } from "../components/index";

class My extends Component {
  render() {
    return (
      <div className="My">
        <Grid />
      </div>
    );
  }
}

export default My;
