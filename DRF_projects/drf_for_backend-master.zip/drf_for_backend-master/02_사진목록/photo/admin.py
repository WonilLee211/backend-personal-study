from django.contrib import admin
from .models import Photo

# Register your models here.
admin.site.register(Photo)